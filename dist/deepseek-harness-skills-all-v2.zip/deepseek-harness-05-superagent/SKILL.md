---
name: deepseek-harness-05-superagent
description: "基于 DeepSeek Super-agent 设计思路，为长期运行、多任务、多信道的 Agent 系统设计协调层、事件路由、持久化与恢复机制，或扩展 dsh-superagent-prototype。适用于系统编排和相关教学；普通单工具插件开发无需使用此技能。 / Design coordination, event routing, persistence, and recovery for long-running, multitask, multichannel agents using DeepSeek Super-agent ideas, or extend dsh-superagent-prototype. Excludes ordinary single-tool plugins."
---

[中文](#中文) | [English](#english)

## 中文

按用户使用的语言回答；仅按需读取对应语言的参考资料。中英文内容表达同一套工作流。

# DeepSeek Harness 05：Super-agent 系统设计

把“人手工管理多个会话”转成系统维护任务、事件、执行与交付。目标是减少人的会话切换和上下文同步负担，同时让结果、阻塞和需要决策的事项可验收。本 Skill 是开发工作流，不能单凭提示词让当前客户端获得常驻服务能力。

## 先确认在设计哪一层

1. 区分用户要理解文章、设计自己的系统，还是修改公开原型。阅读 [设计与验收](references/architecture.md) 的对应部分；修改原型前还需读 [原型对照](references/prototype-map.md)。
2. 建立三列能力清单：文章中的设计、目标代码已实现的能力、本次准备增加的能力。文章与公开仓库并非完全相同；不要把文章的全部设想当成现成 API。
3. 核对真实部署环境、代码提交、`engines`、依赖锁文件与已有事件入口。2026-11-01 核验的原型与 Harness master 环境要求不同，不能套用另一版本的 Node 或宿主结论。

## 系统设计与实施

- **协调与执行分工**：Router 维护全局任务索引、路由和交付状态，Worker 维护具体任务的上下文与执行目录。Router 不承载所有执行细节；给它稳定任务 id 和必要摘要，保留证据引用。
- **事件驱动**：稳定区分 Source、Trigger、Thread、Ticket 与 Assignment。新工作先经过确定性筛选和必要的语义判断；已有任务通过 Subscription 接续上下文，避免每条后续消息都重新开任务。Correlation 提供关联证据，不作为订阅路由的替代。
- **范围与身份**：任务的 Mandate 界定已授予的工作范围。订阅来的上下文、机器人状态、引用文字和语义判断不能自动扩大它；换信道也不默认将不同来源的账号视作同一身份。
- **异步与交互**：把事件接收、路由、长任务执行和回复投递解耦。按任务维护有序输入、取消和回压；一个长工具不应阻塞其他任务的接收。需要人的问题用结构化字段表达，完成或需要行动时通知，普通进度保留在任务记录。
- **持久状态与计算实例**：业务任务状态独立于某次 Worker/Session。事务中记录状态变更与待执行副作用，提交后执行外部工作；恢复时依赖持久记录。为重派设计 assignment id 或代际校验，拒绝旧执行器覆盖新结果。进程重开可恢复不等于已实现跨机迁移。
- **外部 Watchdog**：把基础设施活性与任务实质进展分开检查。监督器不能只靠被监督 Worker 自评；为超时、重复失败和无进展分别定义证据、有限恢复动作与升级条件。单次心跳超时不等于任务偏航，也不直接证明应重做外部写入。
- **交付与重试**：用 Outbox 保留目标信道、稳定消息 id、状态与回执。业务去重、发送重试和接收端幂等分别验证；发送成功但回执未落盘的窗口可能重复投递，不能无条件承诺外部 exactly-once。

## 按任务选择落地方式

- 修改公开原型：沿它的 Runtime、Engine、Assessor、Executor、Outbox、Source 接口扩展，遵守现有领域模型，不另建一套绕过 Engine 的全局任务字典。先读对应源码与测试，再修改。
- 自建系统：先给出事件契约、任务状态、授权边界、持久化和副作用顺序，再实现一个本地闭环。只有用户任务涉及实际平台集成时才配置对应连接；制作架构和 Skill 本身不需要发群消息、创建 PR 或部署后台服务。
- 教学：使用 [离线实验](assets/superagent-lab/demo.py) 和 [测试](assets/superagent-lab/test_coordinator.py)，通过去重、恢复和旧执行器拒绝解释系统不变量。它是原创 Python/SQLite 模型，不是 DeepSeek 插件，不提供 LLM、跨机调度或正式 Watchdog。

## 验收与交付

验证重复事件、跨任务输入、订阅后续事件、长任务期间的新增输入、执行器故障恢复、旧结果隔离，以及通知与回执失败。按实际实现覆盖有风险的路径，不把所有场景机械套给只读教学任务。

交付架构图与契约、代码或配置、来源到实现的能力对照、实际检查证据及剩余边界。观察指标应服务于决策：例如完成/阻塞任务、待人处理事项、恢复次数、重复投递和端到端延迟，而不是用频繁进度通知证明系统在工作。

## 资源

- [设计与验收](references/architecture.md)：学习五项设计、制作架构或制定验收场景时读取。
- [原型对照](references/prototype-map.md)：接入或改造官方公开原型、判断文章设想是否已有代码时读取。
- [实验运行说明](references/lab.md)：运行随附的无凭据实验，理解它验证和没有验证的内容。

官方来源与核验日期见原型对照；本 Skill 不复制公众号全文，也不把公开研究原型称作生产成品。

---

## English

Respond in the user's language and read only the relevant language version of a reference. Both sections describe the same workflow.

# DeepSeek Harness 05: Super-agent System Design

Replace manual coordination across sessions with a system that maintains tasks, events, execution, and delivery. Reduce context synchronization and session switching while making results, blockers, and decisions verifiable. This skill is a development workflow; a prompt alone cannot give the current client a persistent service.

## Identify the layer

1. Determine whether the user wants to understand the article, design a system, or modify the public prototype. Read the relevant [design and acceptance guide](references/architecture.en.md); read the [prototype comparison](references/prototype-map.en.md) before changing the prototype.
2. Create three capability columns: article design, implemented target-code behavior, and proposed additions. The article and public repository differ; not every idea is an existing API.
3. Check the actual environment, commit, `engines`, lockfiles, and event entrypoints. The prototype and Harness `master` checked on 2026-11-01 have different environment requirements; do not transfer Node or host conclusions across versions.

## Design and implementation

- **Coordination and execution:** the Router owns the global task index, routing, and delivery state. Workers own task context and execution directories. Keep execution detail out of the Router; supply stable task IDs, necessary summaries, and evidence references.
- **Events:** distinguish Source, Trigger, Thread, Ticket, and Assignment. Screen new work deterministically and apply semantic assessment where needed. Continue existing work through Subscriptions rather than opening a task for every follow-up. Correlation provides evidence of association, not a replacement for subscription routing.
- **Scope and identity:** a task's Mandate defines granted work. Subscribed context, bot status, quotations, and semantic assessment do not expand it. Accounts on different channels are not automatically the same identity.
- **Asynchronous interaction:** decouple reception, routing, long-running work, and delivery. Maintain ordered inputs, cancellation, and backpressure per task. One long tool must not block reception for other tasks. Express questions for people as structured fields. Notify on completion or required action; keep ordinary progress in task records.
- **Durable state and execution instances:** keep business state independent of a Worker/Session. Record state changes and intended side effects transactionally; perform external work after commit. Recover from durable records. Validate assignment IDs or generations on reassignment so an old executor cannot overwrite a new result. Process restart recovery does not establish cross-machine migration.
- **External Watchdog:** check infrastructure liveness separately from meaningful task progress. Supervision must use more than the supervised Worker's self-assessment. Define evidence, bounded recovery, and escalation for timeout, repeated failure, and stagnation. One missed heartbeat neither proves goal drift nor justifies repeating an external write.
- **Delivery and retries:** persist destination channels, stable message IDs, status, and receipts in an Outbox. Verify business deduplication, retries, and receiver idempotency separately. Sending successfully before a receipt is persisted can cause duplicates; do not promise unconditional external exactly-once delivery.

## Choose an implementation path

- **Modify the public prototype:** extend Runtime, Engine, Assessor, Executor, Outbox, and Source interfaces using its domain model. Do not bypass the Engine with a separate global task dictionary. Read corresponding source and tests first.
- **Build a system:** specify event contracts, task states, authorization, persistence, and side-effect ordering, then implement a local loop. Configure real platform connections only when that integration is in scope. Architecture or skill creation alone does not require group messages, PR creation, or background-service deployment.
- **Teach:** use the [offline demo](assets/superagent-lab/demo.py) and [tests](assets/superagent-lab/test_coordinator.py) to explain deduplication, recovery, and rejection of stale executors. This original Python/SQLite model is not a DeepSeek plugin and supplies no LLM, cross-machine scheduling, or production Watchdog.

## Acceptance and delivery

Verify duplicate events, cross-task input, subscribed follow-ups, input arriving during long work, executor recovery, stale-result isolation, and notification/receipt failures. Cover relevant risks in the actual implementation; do not impose every scenario on read-only teaching.

Deliver architecture and contracts, code or configuration, a source-to-implementation capability comparison, actual verification evidence, and remaining boundaries. Metrics should support decisions: completed/blocked tasks, human action items, recoveries, duplicate deliveries, and end-to-end latency. Frequent progress notifications are not evidence of useful work.

## Resources

- [Design and acceptance](references/architecture.en.md): five design themes, architecture, and acceptance scenarios.
- [Prototype comparison](references/prototype-map.en.md): public-prototype integration, implementation evidence, and article/prototype differences.
- [Lab guide](references/lab.en.md): run the credential-free experiment and understand what it does and does not verify.

See the prototype comparison for official sources and verification dates. This skill does not reproduce the full article or describe a research prototype as a production product.
